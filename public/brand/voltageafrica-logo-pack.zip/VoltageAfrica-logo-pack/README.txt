VoltageAfrica logo pack ("Closing the Gap" identity, v1.0)

Versions: horizontal, stacked, symbol, wordmark. Each as SVG and 2400 px PNG.
Tones: primary (light backgrounds), reverse (dark backgrounds), mono-charcoal, mono-white, on-amber.

Please:
- keep clear space equal to the ring's thickness on every side;
- never stretch, rotate, recolour the amber facet or add effects;
- minimum width: horizontal 130 px, symbol 16 px.
See logo-usage-guide.png.
